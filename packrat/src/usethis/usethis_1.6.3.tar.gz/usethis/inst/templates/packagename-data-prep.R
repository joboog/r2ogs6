## code to prepare `{{{name}}}` dataset goes here

usethis::use_data({{{name}}}, overwrite = TRUE)
