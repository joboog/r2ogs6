library(testit)
test_pkg('xfun')
